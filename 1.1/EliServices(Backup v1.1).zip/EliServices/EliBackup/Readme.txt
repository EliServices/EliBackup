Thanks for getting EliBackup from EliServices!
The following points are important for you, if you want to customize EliBackup. Please read them attentively.

-All configuration data is written in .\elibackup.config
	-Do not change any line, if you don't know what it is doing !!!!
	-Do not add lines in the "General settings" section.
	-Do not remove any lines in the "General settings" section.
	-Do not add any empty lines.
	-Do not remove any empty lines.
	-Do not add space at the and off the lines.

-General Settings:
	-Debugging option displays additional information (recommend: disabled)
	-Autostart option enables a script that autodetects removable drives (recommend: enabled)
	-If Choosedest option is enabled, the programm will ask you for the backuppath and ignores the line in the config file (recommend: disabled)
	-Backuppath is the destination folder where you want your data to be copied to. (requiered if Choosedest is disabled)

-Put the entire path of your individual files in the "Individual files" Section, one line each, only one empty line at the end (still there).
-Put the entire path of your folders in the "Directorys" Section, one line each, no empty lines at all.

-Feel free to contact me per E-Mail (eliservices.server@gmail.com).